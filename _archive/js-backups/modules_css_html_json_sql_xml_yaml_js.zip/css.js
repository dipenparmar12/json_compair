// Need to download this file from the CodeMirror distribution
// https://codemirror.net/5/mode/css/css.js
// This file provides CSS syntax highlighting for CodeMirror
