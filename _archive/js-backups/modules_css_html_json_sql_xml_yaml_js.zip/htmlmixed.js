// Need to download this file from the CodeMirror distribution
// https://codemirror.net/5/mode/htmlmixed/htmlmixed.js
// This file provides HTML syntax highlighting for CodeMirror
// Note: This requires xml.js, css.js, and javascript.js to work properly
