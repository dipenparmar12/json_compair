// Need to download this file from the CodeMirror distribution
// https://codemirror.net/5/mode/sql/sql.js
// This file provides SQL syntax highlighting for CodeMirror
