// Need to download this file from the CodeMirror distribution
// https://codemirror.net/5/mode/xml/xml.js
// This file provides XML syntax highlighting for CodeMirror
