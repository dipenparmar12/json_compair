// Need to download this file from the CodeMirror distribution
// https://codemirror.net/5/mode/yaml/yaml.js
// This file provides YAML syntax highlighting for CodeMirror
